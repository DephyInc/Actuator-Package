//Use this file to test on a PC, outside of the Plan project. It's currently only
//used by DephyInc/commTest.

#ifdef TEST_PC

#ifndef INC_USER_TEST_PC_H
#define INC_USER_TEST_PC_H

//****************************************************************************
// Include(s)
//****************************************************************************

//#include "main.h"
#include "flexsea_board.h"
#include "flexsea_sys_def.h"
#include "flexsea_global_structs.h"

//****************************************************************************
// Public Function Prototype(s):
//****************************************************************************

/*
void init_user(void);
void user_fsm_1(void);
void user_fsm_2(void);
*/

//****************************************************************************
// Definition(s):
//****************************************************************************

//Step 1) Select active project (from list):
//==========================================

//#define ACTIVE_PROJECT			99
//#define ACTIVE_SUBPROJECT		SUBPROJECT_NONE


//****************************************************************************
// Structure(s)
//****************************************************************************


//****************************************************************************
// Shared variable(s)
//****************************************************************************


#endif	//INC_USER_TEST_PC_H

#endif //TEST_PC
