# Actuator-Package
FlexSEA-Rigid Actuator Package library and sample programs
Please refer to http://dephy.com/wiki/flexsea/doku.php (direct link: http://dephy.com/wiki/flexsea/doku.php?id=actpackpython) for all the details.
